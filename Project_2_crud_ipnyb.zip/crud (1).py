# crud.py
#
# CRUD operations for the Austin Animal Center (AAC) animals collection.

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    CRUD operations for the AAC animal collection in MongoDB.
    """

    def __init__(self, username, password,
                 host="localhost", port=27017,
                 db_name="aac", collection_name="animals"):
        """
        Initialize the MongoClient using the provided username and password.
        User aacuser should have been created in the admin database with
        readWrite on the aac database.
        """
        try:
            # Authenticate against the admin database, then use aac
            uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin"
            self.client = MongoClient(uri)
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
        except PyMongoError as e:
            print(f"[ERROR] Could not connect to MongoDB: {e}")
            self.client = None
            self.database = None
            self.collection = None

    # CREATE
    def create(self, data: dict) -> bool:
        """
        Insert a document into the collection.

        :param data: dict representing the document to insert.
        :return: True if insert succeeds, otherwise False.
        """
        if not isinstance(data, dict) or not data:
            print("[WARNING] create() called with empty or invalid data.")
            return False

        if self.collection is None:
            print("[ERROR] No collection available. Check MongoDB connection.")
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"[ERROR] Insert failed: {e}")
            return False

    # READ
    def read(self, query: dict) -> list:
        """
        Query for documents in the collection.

        :param query: dict representing the MongoDB query filter.
        :return: List of matching documents, or an empty list on error.
        """
        if self.collection is None:
            print("[ERROR] No collection available. Check MongoDB connection.")
            return []

        if not isinstance(query, dict):
            print("[WARNING] read() query must be a dictionary.")
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"[ERROR] Read failed: {e}")
            return []

    # UPDATE
    def update(self, query: dict, new_values: dict) -> int:
        """
        Update document(s) matching query with new_values.

        :param query: dict filter for documents to update.
        :param new_values: dict of fields to change, wrapped in $set internally.
        :return: Number of documents modified.
        """
        if self.collection is None:
            print("[ERROR] No collection available. Check MongoDB connection.")
            return 0

        if not isinstance(query, dict) or not isinstance(new_values, dict):
            print("[WARNING] update() requires query and new_values as dicts.")
            return 0

        try:
            update_doc = {"$set": new_values}
            result = self.collection.update_many(query, update_doc)
            return result.modified_count
        except PyMongoError as e:
            print(f"[ERROR] Update failed: {e}")
            return 0

    # DELETE
    def delete(self, query: dict) -> int:
        """
        Delete document(s) matching query.

        :param query: dict filter for documents to delete.
        :return: Number of documents deleted.
        """
        if self.collection is None:
            print("[ERROR] No collection available. Check MongoDB connection.")
            return 0

        if not isinstance(query, dict):
            print("[WARNING] delete() query must be a dictionary.")
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"[ERROR] Delete failed: {e}")
            return 0
